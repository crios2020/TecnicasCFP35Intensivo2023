public class Clase02{
    public static void main(String[] args) {
        // Escribimos código en esta parte

        /*
         * Trayecto: Programador

        Curso: 	Técnicas de programación 120 hs
        Días:	Lunes Miércoles Viernes		09:00 hs a 13:00 hs
        Modalidad:		Lunes		presencial	(Algarrobo 1041)
                        Miércoles	virtual sincrónico
                        Viernes		virtual asincrónico
                        
        Profe:	Carlos Ríos			c.rios@bue.edu.ar

        Materiales:
                    Aula virtual: 
                    https://aulasvirtuales.bue.edu.ar/course/view.php?id=12662
                    
                    Github: https://github.com/crios2020/TecnicasCFP35Intensivo2023
                    
                    CodeShare: https://codeshare.io/crios2020
                    
        Software:	
                    JDK		Java Develoment Kit	(Kit de Desarrollo Java)
                    JDK	17 LTS		Long Term Support (5 años)
                    https://www.oracle.com/ar/java/technologies/downloads/#java17
                    
                    GIT		Control de versiones(windows).
                    https://git-scm.com/				
                    
                    IDE		Integrated Development Enviroment. 
                            (Entorno de desarrollo integrado)
                    
                    VSCode - Eclipse - IntelliJ - Netbeans
                    https://code.visualstudio.com/
                            Extensiones:		Extension Pack for Java (Microsoft)
                    
                    
         */

        //linea Comentarios
        /*
         * Bloque
         * de
         * comentarios
         */
        
        //TODO Tarea pendiente!
        
        System.out.println("Hola Mundo!!!");  //imprime en consola
        //lenguaje es case sensitive (sensible a las minusculas y mayusculas)
        // ; es el terminador de sentencias
        // F5 para ejecutar

        //sout tab atajo de teclado para System.out.println();
        System.out.println("Centro de Formación Profesional Nro 35");
        System.out.println("Profe Carlos Rios");

        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Hoy es Viernes!");

        /*
         *          Hola Mundo!!!
         *          Centro de Formación Profesional Nro 35
         *          Profe Carlos Rios
         *          1234
         *          Hoy es Viernes!
         *          
         */

        //Colores ANSI
        String black="\033[30m"; 
        String red="\033[31m"; 
        String green="\033[32m"; 
        String yellow="\033[33m"; 
        String blue="\033[34m"; 
        String purple="\033[35m"; 
        String cyan="\033[36m"; 
        String white="\033[37m";
        String reset="\u001B[0m";
        System.out.println("\u001B[31mTexto en rojo\u001B[0m");

        System.out.println(green+"Feliz día de San Patricio"+reset);

        //Versión de Java
        System.out.println("Versión de java: "+System.getProperty("java.version"));

        //Arte ANSI java 17
        //https://fsymbols.com/es/arte-de-texto/
        System.out.println(
            cyan+
            """
            _____________¶¶¶¶¶¶¶
            ___________¶¶¶______¶¶¶
            _________¶¶¶___________¶¶
            ________¶¶______________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
            _______¶¶___________________¶_______¶¶¶¶¶
            ______¶¶________________________________¶¶¶
            _____¶¶___________________________________¶¶
            ____¶¶___________________¶¶________________¶¶
            ____¶¶___________________¶¶_________________¶
            ___¶¶____________________¶__________________¶
            ___¶¶___¶¶__________________________________¶
            __¶¶__¶_¶¶¶¶¶_______________________________¶¶
            __¶¶_¶¶¶¶¶¶¶¶¶______________________________¶¶¶
            __¶__¶¶¶¶¶¶¶¶¶______________________________¶¶¶
            __¶_¶¶¶¶¶¶¶¶¶¶¶¶___________________________¶¶
            __¶_¶¶¶_¶¶¶_¶¶_¶¶_________________________¶¶
            __¶_¶¶_¶¶¶¶¶¶¶¶_¶_______________________¶¶
            __¶_¶¶__¶¶¶¶¶¶¶_¶¶___¶¶______________¶¶¶¶
            __¶_¶¶__¶¶¶¶¶¶¶_¶¶____¶___________¶¶¶¶
            __¶_¶¶¶¶¶¶¶__¶¶_¶¶_____¶¶¶¶___¶¶¶¶¶
            ___¶_¶¶¶¶¶¶__¶¶_¶__________¶¶¶¶
            ___¶¶__¶¶¶¶¶¶¶__¶¶¶¶______¶¶¶
            ____¶¶___¶¶¶___¶¶¶¶¶¶____¶¶
            _____¶¶¶_____¶¶¶____¶_____¶¶¶
            ________¶¶¶¶¶¶_____¶¶¶¶¶¶¶¶¶
            ____________________¶¶_____¶¶
            ____________________¶_______¶¶
            ____________________¶________¶¶
            ___________________¶¶_________¶¶
            ___________________¶____¶¶_____¶¶
            __________________¶¶____¶¶______¶¶
            __________________¶_¶____¶_______¶¶
            _________________¶¶_¶____¶¶______¶¶
            ___________¶¶¶¶__¶¶_¶_____¶______¶¶
            ____________¶¶¶¶¶¶¶_¶_____¶______¶¶
            _____________¶¶__¶_¶______¶_____¶¶¶___¶¶¶
            _______________¶¶¶_¶___¶__¶_____¶¶__¶¶¶_¶¶
            _____________¶¶__¶_¶¶__¶_¶¶___¶¶___¶¶____¶¶
            ____________¶¶¶¶__¶_¶¶¶¶¶_____¶¶__¶¶_____¶¶
            ___________¶¶__¶¶¶¶____________¶¶¶_______¶¶
            ___________¶¶___¶¶____¶¶¶¶¶_____¶_____¶_¶¶
            ____________¶________¶____¶____________¶¶
            ____________¶_______¶¶____¶¶______¶¶___¶¶
            ____________¶¶_______¶¶___¶¶________¶¶¶¶
            _____________¶¶_______¶¶_¶¶_________¶¶
            _____________¶¶__¶¶____¶¶_________¶¶
            ______________¶¶_¶¶_¶__¶_______¶¶¶¶
            _______________¶¶¶__¶¶¶¶¶__¶¶¶¶¶
            _________________¶¶¶¶¶__¶¶¶¶¶
            
            """
            +reset);

        //Tipo de dato primitivos
        /*
         * Memoria RAM:         Volatil         Caro            Veloz
         * 
         * Disco Duro HDD:      Persistente     Economico       Lento
         * 
         * 
         * 
         * Lenguajes de tipado fuerte:  JAVA C C++ C# VisualBasic Pascal
         * 
         * Lenguajes de tipado debil:   PHP Python JavaScript
         * 
         */
    
        // Tipo de datos entero
        int a;                      //declaración de variable
        a=2;                        //asignación de valor
        int b=4;                    //declaración y asignación de valor
        int c=a+b;  //6

        int d=26, e=65, f=38, g=29; //declaración y asignación multiple

        //Una variable solo puede declararse una vez.
        //una variable puede tener infinitas asignaciones de valor.

        //int a;      //error variable ya declarada.
        a=23;
        a=45;
        a=72;
        a=5;

        System.out.println(a);
        System.out.println("variable a: "+a);
        System.out.println(a+b);                        //  9
        System.out.println("a+b="+a+b);                 // 54
        System.out.println("a+b="+(a+b));               //  9

        //tipo de datos String
        String p="perro";
        String l="ladra";
        System.out.println(p+l);            //perroladra
        System.out.println(p+" "+l);        //perro ladra
        System.out.println(p+" que "+l);    //perro que ladra
        System.out.println(purple+p+" que "+l+reset);

        //Tipo de datos boolean
        boolean llueve=false;
        System.out.println(llueve);
        llueve=true;
        System.out.println(llueve);

        //Tipo da datos char
        char ch=65;
        System.out.println(ch);
        ch+=32;                     //sumamos 32 a la variable
        System.out.println(ch);

        //Tipo de datos float   32 bit
        float fl=4.55f;
        System.out.println(fl);

        //Tipo de datos double  64 bits
        double dl=4.55;
        System.out.println(dl);

        fl=10;
        dl=10;

        System.out.println(fl/3);
        System.out.println(dl/3);


        //Constantes
        //Las constantes solo pueden tener una sola asignación de valor
        //final double PI=3.14;
        final double PI=Math.PI;
        //PI=4;                 //Erro no se puede cambiar el valor de una CTE
        System.out.println(PI);

        //Identificadores de variables validos
        int nro1=4;     //OK
        //int 1nro=4;     //Error
        int _nro1=4;    //OK
        int $nro1=5;    //OK
        //int %nro1=6;    //Error

        //Ingreso por consola
        System.out.print(green+"Ingrese su nombre: ");
        String nombre=new java.util.Scanner(System.in).next();
        System.out.println("hola "+nombre+reset);
        
        //TODO Operadores Java

        //TODO Operadores Logicos




    }
}