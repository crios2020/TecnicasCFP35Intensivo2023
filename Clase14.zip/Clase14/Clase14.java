import javax.swing.JOptionPane;

public class Clase14 {
    public static void main(String[] args) {

   
        //sumar(65,39);
        //sumar(26,29);

        //System.out.println(suma(65,39));
        //System.out.println(suma(23,38));

        //JOptionPane.showMessageDialog(null, "Hola a todos!!!");
        JOptionPane.showMessageDialog(null, "Suma: "+suma(33,69));

    }

    //función con ingreso de parámetros sin valor de retorno
    private static void sumar(int nro1,int nro2){
        System.out.println(nro1+nro2);
    }

    //función con ingreso de parámetros con valor de retorno
    private static int suma(int nro1,int nro2){
        return nro1+nro2;
    }

}
