import java.util.Scanner;

public class Login {
    
    //Variables globales
    //Colores ANSI
    static String black="\033[30m";            
    static String red="\033[31m";              
    static String green="\033[32m";            
    static String yellow="\033[33m";           
    static String blue="\033[34m";             
    static String purple="\033[35m";           
    static String cyan="\033[36m";             
    static String white="\033[37m";            
    static String reset="\u001B[0m";

    public static void main(String[] args) {
        //Programa principal o punto de entrada!

        cartelBienvenida();

        String user="";
        String pass="";
        if(args.length==2){
            user=args[0];
            pass=args[1];
        }else{
            System.out.print(blue+"Ingrese su nombre de Usuario: ");
            user=inputString();
            System.out.print(blue+"Ingrese su clave: ");
            pass=inputString();
        }
        if(user.equals("root") && pass.equals("123")){
            cartelOk();
            System.out.println(blue+"Bienvenido Usuario!"); 
            Hoy.main(null); 
        }   
        if(user.equals("root") && !pass.equals("123")){
            cartelNo();
            System.out.println(red+"Clave Incorrecta!");
        }  
        if(!user.equals("root")){
            cartelNo();
            System.out.println(red+"Usuario Incorrecto!");
        }                                  
        System.out.println(reset);
    }

    //Función que permite el ingreso de valores String por consola
    private static String inputString(){
        return new Scanner(System.in).nextLine();
    }

    private static void cartelNo() {
        System.out.println(red+"""
            ███████▄▄███████████▄
            ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓▓███░░░░░░░░░░░░█
            ██████▀░░█░░░░██████▀
            ░░░░░░░░░█░░░░█
            ░░░░░░░░░░█░░░█
            ░░░░░░░░░░░█░░█
            ░░░░░░░░░░░█░░█
            ░░░░░░░░░░░░▀▀    
        """);
    }

    private static void cartelOk() {
        System.out.println(green+"""
            ░░░░░░░░░░░▄▄
            ░░░░░░░░░░█░░█
            ░░░░░░░░░░█░░█
            ░░░░░░░░░█░░░█
            ░░░░░░░░█░░░░█
            ██████▄▄█░░░░░██████▄
            ▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓█░░░░░░░░░░░░░░█
            ▓▓▓▓▓█████░░░░░░░░░█
            █████▀░░░░▀▀██████▀
        """);
    }

    private static void cartelBienvenida() {
        System.out.println(green);
        System.out.println("╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║                 LOGIN DEL SISTEMA                             ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝");
        System.out.println();
    }

    

}
