import java.util.Scanner;

public class Login{
    public static void main(String[] args) {
        // Ejercicio 5
        // Tomando el siguiente código:String usuario = “root”, clave= “1234”;
        // Informar los siguientes casos:
        //      1.Si el usuario es ”root” y la clave es ”1234” informar “¡Bienvenido al sistema!”.
        //      2.Si el usuario es ”root” y la clave no es “1234” informar “Contraseña incorrecta”.
        //      3.Si el usuario no es “root” y la clave es “1234” informar “Usuario incorrecto”.
            
        //Colores ANSI
        String black="\033[30m";
        String red="\033[31m";
        String green="\033[32m";
        String yellow="\033[33m";
        String blue="\033[34m";
        String purple="\033[35m";
        String cyan="\033[36m";
        String white="\033[37m";
        String reset="\u001B[0m";

        System.out.println(green);
        System.out.println("*****************************************************************");
        System.out.println("*                 LOGIN DEL SISTEMA                             *");
        System.out.println("*****************************************************************");
        System.out.println();
        System.out.print("Ingrese su nombre de Usuario: ");
        String usuario=new Scanner(System.in).nextLine();
        System.out.print("Ingrese su clave: ");
        String clave=new Scanner(System.in).nextLine();
        if(usuario.equals("root") && clave.equals("123")){
            System.out.println(green+"""
                ░░░░░░░░░░░▄▄
                ░░░░░░░░░░█░░█
                ░░░░░░░░░░█░░█
                ░░░░░░░░░█░░░█
                ░░░░░░░░█░░░░█
                ██████▄▄█░░░░░██████▄
                ▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓█████░░░░░░░░░█
                █████▀░░░░▀▀██████▀
            """);
            System.out.println(blue+"Bienvenido Usuario!");  
        }   
        if(usuario.equals("root") && !clave.equals("123")){
            System.out.println(red+"""
                ███████▄▄███████████▄
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓███░░░░░░░░░░░░█
                ██████▀░░█░░░░██████▀
                ░░░░░░░░░█░░░░█
                ░░░░░░░░░░█░░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░░▀▀    
                    """);
            System.out.println(red+"Clave Incorrecta!");
        }  
        if(!usuario.equals("root")){
            System.out.println(red+"""
                ███████▄▄███████████▄
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓███░░░░░░░░░░░░█
                ██████▀░░█░░░░██████▀
                ░░░░░░░░░█░░░░█
                ░░░░░░░░░░█░░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░░▀▀    
                    """);
            System.out.println(red+"Usuario Incorrecto!");
        }                                  
        System.out.println(reset);

    }
}