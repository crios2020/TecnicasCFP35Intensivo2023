public class Clase09 {
    public static void main(String[] args) {
        //Clase 09
        //Estructura while
        int a=20;
        System.out.println("-- Inicio de estructura while --");
        while(a<=10){
            System.out.println(a);
            a++;
        }
        System.out.println("-- Fin de esctructura while --");
        System.out.println(a);
        
        //Estructura doWhile
        a=20;
        System.out.println("-- Inicio de estructura doWhile --");
        do{
            System.out.println(a);
            a++;
        }while(a<=10);
        System.out.println("-- Fin de estructura doWhile --");
        System.out.println(a);

        //Modo expandido de llaves
        a=1;
        while(a<=10)
        {
            System.out.println(a);
            a++;
        }

        //Modo abreviado de llaves
        a=1;
        while(a<=10) System.out.println(a++);

        //loop infinito
        // a=1;
        // while(true){
        //     System.out.println(a);
        //     a++;
        // }
        
        //loop infinito
        // a=1;
        // while (a<=10 || true) {
        //     System.out.println(a);
        //     a++;
        // }

        //loop infinito
        // a=1;
        // while (a<=10 || a>=0) {
        //     System.out.println(a);
        //     a++;
        // }

        //loop infinito
        // a=1;
        // while (a<=10) {
        //     System.out.println(a--);
        //     a++;
        // }

        //loop infinito
        // a=1;
        // while (a<=10);
        // {
        //     System.out.println(a);
        //     a++;
        // }
        

        //TODO Laboratorios de While


    }
}
