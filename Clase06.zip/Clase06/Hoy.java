import java.time.LocalDate;
import java.util.Calendar;

import javax.tools.Diagnostic;

public class Hoy {
    public static void main(String[] args) {
        Calendar calendar=Calendar.getInstance();
        LocalDate ld=LocalDate.now();

        //Colores ANSI
        String black="\033[30m";
        String red="\033[31m";
        String green="\033[32m";
        String yellow="\033[33m";
        String blue="\033[34m";
        String purple="\033[35m";
        String cyan="\033[36m";
        String white="\033[37m";
        String reset="\u001B[0m";

        int diaMes=ld.getDayOfMonth();
        int mes=ld.getMonthValue(); 
        String mesNombre="";
        int dia=ld.getDayOfWeek().getValue();
        String diaSemana="";
        int anio=ld.getYear();
        String zona=calendar.getTimeZone().getID();

        // día de la semana
        // if(dia==1) diaSemana="Lunes";
        // if(dia==2) diaSemana="Martes";
        // if(dia==3) diaSemana="Miércoles";
        // if(dia==4) diaSemana="Jueves";
        // if(dia==5) diaSemana="Viernes";
        // if(dia==6) diaSemana="Sábado";
        // if(dia==7) diaSemana="Domingo";

        // Azucar Sintáctico
        switch(dia){
            case 1: diaSemana="Lunes";          break;
            case 2: diaSemana="Martes";         break;
            case 3: diaSemana="Miércoles";      break;
            case 4: diaSemana="Jueves";         break;
            case 5: diaSemana="Viernes";        break;
            case 6: diaSemana="Sábado";         break;
            case 7: diaSemana="Domingo";        break;
        }

        // nombre de mes
        // if(mes==1) mesNombre="Enero";
        // if(mes==2) mesNombre="Febrero";
        // if(mes==3) mesNombre="Marzo";
        // if(mes==4) mesNombre="Abril";
        // if(mes==5) mesNombre="Mayo";
        // if(mes==6) mesNombre="Junio";
        // if(mes==7) mesNombre="Julio";
        // if(mes==8) mesNombre="Agosto";
        // if(mes==9) mesNombre="Septiembre";
        // if(mes==10) mesNombre="Octubre";
        // if(mes==11) mesNombre="Noviembre";
        // if(mes==12) mesNombre="Diciembre";

        switch(mes){
            case 1:     mesNombre="Enero";          break;
            case 2:     mesNombre="Febrero";        break;
            case 3:     mesNombre="Marzo";          break;
            case 4:     mesNombre="Abril";          break;
            case 5:     mesNombre="Mayo";           break;
            case 6:     mesNombre="Junio";          break;
            case 7:     mesNombre="Julio";          break;
            case 8:     mesNombre="Agosto";         break;
            case 9:     mesNombre="Septiembre";     break;
            case 10:    mesNombre="Octubre";        break;
            case 11:    mesNombre="Noviembre";      break;
            case 12:    mesNombre="Diciembre";      break;
        }

        System.out.println(green);
        System.out.println("Hoy es "+diaSemana+" "+diaMes+" de "+mesNombre+" de "+anio);
        zona=zona.replace("/", " ");
        zona=zona.replace("_", " ");
        System.out.println(zona);
        
        System.out.println(reset);
    }
}
