public class Clase06 {
    public static void main(String[] args) {
        //Utilidades de la clase String

        String texto="Esto es una cadena de texto!!";

        //métodos toLowerCase() toUpperCase()
        System.out.println(texto.toLowerCase());
        System.out.println(texto.toUpperCase());

        //método substring()
        System.out.println(texto.substring(5));
        System.out.println(texto.substring(5, 15));

        //método trim()
        System.out.println("    Hola a todos!!    ".trim());

        //startsWith() endsWith()
        System.out.println(texto.startsWith("hola"));       //false
        System.out.println(texto.startsWith("Esto"));       //true
        System.out.println(texto.endsWith("chau"));         //false
        System.out.println(texto.endsWith("!!"));           //true

        System.out.println(texto.startsWith("esto"));       //false
        System.out.println(texto.toLowerCase().startsWith("esto")); //true

        //chartAt()
        System.out.println(texto.charAt(5));
        System.out.println(texto.charAt(6));
        System.out.println(texto.charAt(8));

        //length()
        System.out.println(texto.length());
        System.out.println("hola".length());        //4

        //indexOf()
        System.out.println(texto.indexOf("a"));
        System.out.println(texto.indexOf("c"));


        //Ejercicio 1 – Operadores Booleanos
        //Analice el código a continuación y complete la tabla correspondiente. Luego realice la codificación
        //para confirmar que ha completado la tabla correctamente.
        
        System.out.println("A");
        int x = 10;
        int y = 20;
        boolean log1 = x==y;
        boolean log2 = x!=y;
        System.out.println(log1);           //false
        System.out.println(log2);           //true

        System.out.println("B");
        log1 = (x+=5) == (y-=5);            //true
        log2 = x == y;                      //true
        System.out.println(log1);
        System.out.println(log2);

        System.out.println("C");
        log1 =! log1;                       //false
        log2 =!! log2;                      //true
        System.out.println(log1);
        System.out.println(log2);

        System.out.println("D");
        log1 = log1 || log2;                //true
        log2 =!log1 && log2;                //false
        System.out.println(log1);
        System.out.println(log2);

        System.out.println("E");
        log1 = log2 && x!=15;               //false
        log1 = y == 10+5;                   //true
        System.out.println(log1);
        System.out.println(log2);


        //Tabla para completar:
        
        //          log1        log2
        //  A       false       true
        //  B       true        true
        //  C       false       true
        //  D       true        false
        //  E       true        false


        //TODO Laboratorio
        // Ejercicio 1
        // Generar un programa que permita al usuario ingresar por consola en la misma línea el primer
        // nombre y primer apellido y realice las siguientes operaciones:
        // 1. Mostrar el nombre y apellido por separado.
        // 2. Mostrar las iniciales en mayúsculas.
        // Ejercicio 2
        // Realizar un programa que permita al usuario ingresar por consola dos números y realice las
        // siguientes operaciones:
        // 1. El usuario debe poder ingresar la cantidad de decimales que desea ver en el resultado.
        // 2. Sacar la potencia de los números ingresados.
        // Ejercicio 3
        // Se pide un programa que ingrese por consola dos letras y realice la siguiente operación:
        // 1. Mostrar la representación ASCII de las letras en minúsculas y mayúsculas.
        // Ejercicio 4
        // Generar un programa que permita al usuario ingresar por consola la base y altura de un triangulo
        // rectángulo.
        // 1. Mostrar largo de la hipotenusa.
        // 2. Mostrar perímetro del triangulo.
        // 3. Mostrar la superficie del triangulo.
        // Ejercicio 5
        // En una variable del tipo double asignar la siguiente operación matemáticas 10000000/3.
        // 1. Imprimir el valor de la variable con el siguiente formato 3.333.333,33
        // Ejercicio 6

        // Ejercicio 7

    }
}
