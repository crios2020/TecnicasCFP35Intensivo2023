
import java.text.DecimalFormat;
import java.util.Scanner;

public class Clase07{
    public static void main(String[] args) {
        
        // Laboratorio
        // Ejercicio 1
        // Generar un programa que permita al usuario ingresar por consola 
        // en la misma línea el primer nombre y primer apellido 
        // y realice las siguientes operaciones:
        // 1. Mostrar el nombre y apellido por separado.
        // 2. Mostrar las iniciales en mayúsculas.
        // System.out.print("Ingrese su nombre y apellido: ");
        // String nombre=new Scanner(System.in).nextLine();
        // //carlos rios
        // int space=nombre.indexOf(" ");

        // String primerNombre=nombre.substring(0, space);
        // String segundoNombre=nombre.substring(space+1, nombre.length());
        // System.out.println(primerNombre);
        // System.out.println(segundoNombre);

        // primerNombre=primerNombre.substring(0,1).toUpperCase()
        //             +primerNombre.substring(1).toLowerCase();
        // segundoNombre=segundoNombre.substring(0,1).toUpperCase()
        //             +segundoNombre.substring(1).toLowerCase();
        // System.out.println(primerNombre);
        // System.out.println(segundoNombre);

        // Ejercicio 2
        // Realizar un programa que permita al usuario ingresar por consola dos 
        // números y realice las siguientes operaciones:
        // 1. El usuario debe poder ingresar la cantidad de decimales que desea 
        // ver en el resultado.
        // 2. Sacar la potencia de los números ingresados.
        // double precio1=(double)10/3;
        // double precio2=155.1235656565;
        // System.out.print("Ingrese la cantidad de decimales: ");
        // int cantidadDecimales=new Scanner(System.in).nextInt();
        // //DecimalFormat df=new DecimalFormat("###,###,###.000");

        // System.out.println(precio1);
        // System.out.println(precio2);

        // double precioDouble1=precio1*Math.pow(10, cantidadDecimales);
        // double precioDouble2=precio2*Math.pow(10, cantidadDecimales);

        // int precioInt1=(int)precioDouble1;
        // int precioInt2=(int)precioDouble2;

        // // System.out.println(precioInt1);
        // // System.out.println(precioInt2);

        // precioDouble1=(double)precioInt1/Math.pow(10, cantidadDecimales);
        // precioDouble2=(double)precioInt2/Math.pow(10, cantidadDecimales);

        // System.out.println("Redondeo de decimales: ");
        // System.out.println(precioDouble1);
        // System.out.println(precioDouble2);

        // System.out.println("Potencia: ");
        // System.out.println(Math.pow(precioDouble1, 2));
        // System.out.println(Math.pow(precioDouble2, 2));


        // Ejercicio 3
        // Se pide un programa que ingrese por consola dos letras y realice 
        // la siguiente operación:
        // 1. Mostrar la representación ASCII de las letras en minúsculas 
        //    y mayúsculas.
        // System.out.println("Ingrese letra 1:");
        // String letra1=new Scanner(System.in).nextLine();
        // System.out.println("Ingrese letra 2:");
        // String letra2=new Scanner(System.in).nextLine();
        // letra1=letra1.substring(0,1);
        // letra2=letra2.substring(0,1);
        // System.out.println("Letra 1 en minúscula: "+letra1.toLowerCase());
        // System.out.println("Letra 1 en mayúscula: "+letra1.toUpperCase());
        // System.out.println("Letra 2 en minúscula: "+letra2.toLowerCase());
        // System.out.println("Letra 2 en mayúscula: "+letra2.toUpperCase());
        
        // Ejercicio 4
        // Generar un programa que permita al usuario ingresar por consola 
        // la base y altura de un triangulo rectángulo.
        // 1. Mostrar largo de la hipotenusa.
        // 2. Mostrar perímetro del triangulo.
        // 3. Mostrar la superficie del triangulo.
        // System.out.println("Ingrese la base y la altura de un triangulo rectángulo");
        // System.out.print("base: ");
        // int base=new Scanner(System.in).nextInt();
        // System.out.print("altura: ");
        // int altura=new Scanner(System.in).nextInt();

        // int hipotenusa=(int)Math.hypot(base, altura);
        // System.out.println("Hipotenusa: "+hipotenusa);

        // int perimetro=hipotenusa+base+altura;
        // System.out.println("Perímetro: "+perimetro);

        // int superficie=base*altura/2;
        // System.out.println("Superficie: "+superficie);


        // Ejercicio 5
        // En una variable del tipo double asignar la siguiente operación 
        // matemáticas 10000000/3.
        // 1. Imprimir el valor de la variable con el siguiente formato 
        // 3.333.333,33

        double variable=(double)10000000/3;
        System.out.println(variable);
        DecimalFormat df=new DecimalFormat("###,###,###.00");
        System.out.println(df.format(variable));
        
        System.out.println("Versión de java: "+System.getProperty("java.version"));
       
        // Ejercicio 6
        //Colores ANSI
        String black="\033[30m";
        String red="\033[31m";
        String green="\033[32m";
        String yellow="\033[33m";
        String blue="\033[34m";
        String purple="\033[35m";
        String cyan="\033[36m";
        String white="\033[37m";
        String reset="\u001B[0m";

        System.out.println(black    +"Aprendiendo Programación"+reset);
        System.out.println(red      +"Aprendiendo Programación"+reset);
        System.out.println(green    +"Aprendiendo Programación"+reset);
        System.out.println(yellow   +"Aprendiendo Programación"+reset);
        System.out.println(blue     +"Aprendiendo Programación"+reset);
        System.out.println(purple   +"Aprendiendo Programación"+reset);
        System.out.println(cyan     +"Aprendiendo Programación"+reset);
        System.out.println(white    +"Aprendiendo Programación"+reset);

        // Ejercicio 7
        System.out.println(red+"""
                    ∵*.•´¸.•*´✶´♡
                    ° ☆ °˛*˛☆_Π______*˚☆*
                    ˚ ˛★˛•˚*/______/~⧹。˚˚
                    ˚ ˛•˛•˚｜ 田田｜門｜ ˚*
                    🌷╬╬🌷╬╬🌷╬╬🌷╬╬🌷
                """+reset);


                //Ejercicio 10
                // Dados los siguientes números n1=5, n2=10 y n3=20. Informar:
                // a) n1+n2
                // b) n3-n1
                // c) n1*n3
                // d) n3/n2
                // Ejemplo:
                int n1=5;
                int n2=10;
                System.out.println(n1+n2);

                /*
                 *          Valor   
                 *  A
                 *  B
                 *  C
                 *  D
                 * 
                 */

                // Ejercicio 11
                // Dados n1=10, n2=20 y n3=30. Informar :
                // a) El total
                // b) El promedio
                // c) El resto entre n2 y n1

                /*
                 *          Valor   
                 *  A
                 *  B
                 *  C
                 *  D
                 * 
                 */

                //Ejercicio 12
                //Dados n1=true, n2=false y n3=true. Informar :
                // a) n1 ^ n2
                // b) (n1 & !n2) | n3
                // c) (n1 | n2) & !n3

                /*
                 *          Valor   
                 *  A
                 *  B
                 *  C
                 *  D
                 * 
                 */

                //Ejercicio 13
                //Declarar dos variables n1=5 y n2=10.
                //Utilizando concatenación entre las variables y los literales, mostrar en pantalla la siguiente
                //expresión:

                // n1 es igual a 5,n2 es igual a 10 y n1 más n2 es igual a 15.


                // Ejercicio 14 - Uso de constantes
                // Haciendo uso de la constante IVA=21,calcular el precio con iva de los siguientes productos e
                // informar:
                // a) remera:59.90$
                // b) pantalón:99.90$
                // c) campera:149.90$

                
    }
}