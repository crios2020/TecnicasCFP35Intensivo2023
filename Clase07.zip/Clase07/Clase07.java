public class Clase07{
    public static void main(String[] args) {
        
        // Laboratorio
        // Ejercicio 1
        // Generar un programa que permita al usuario ingresar por consola en la misma línea el primer
        // nombre y primer apellido y realice las siguientes operaciones:
        // 1. Mostrar el nombre y apellido por separado.
        // 2. Mostrar las iniciales en mayúsculas.
        // Ejercicio 2
        // Realizar un programa que permita al usuario ingresar por consola dos números y realice las
        // siguientes operaciones:
        // 1. El usuario debe poder ingresar la cantidad de decimales que desea ver en el resultado.
        // 2. Sacar la potencia de los números ingresados.
        // Ejercicio 3
        // Se pide un programa que ingrese por consola dos letras y realice la siguiente operación:
        // 1. Mostrar la representación ASCII de las letras en minúsculas y mayúsculas.
        // Ejercicio 4
        // Generar un programa que permita al usuario ingresar por consola la base y altura de un triangulo
        // rectángulo.
        // 1. Mostrar largo de la hipotenusa.
        // 2. Mostrar perímetro del triangulo.
        // 3. Mostrar la superficie del triangulo.
        // Ejercicio 5
        // En una variable del tipo double asignar la siguiente operación matemáticas 10000000/3.
        // 1. Imprimir el valor de la variable con el siguiente formato 3.333.333,33
        // Ejercicio 6

        // Ejercicio 7
    }
}