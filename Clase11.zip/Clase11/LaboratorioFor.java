public class LaboratorioFor {
    public static void main(String[] args) {

        //Utilizar la estructura for

        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.

        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.

        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.

        // Ejercicio 4
        // Imprimir la suma de los números impares del 1 al 10.

        // Ejercicio 5
        // Mostrar la suma de la multiplicación de los números del 1 al 5 con la suma de los números del 1 al 5.

        // Ejercicio 6
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @
        // @
        // @

        // Ejercicio 7
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @
        // @@
        // @

        // Ejercicio 8
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@

        // Ejercicio 9
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @

        // Ejercicio 10
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@
        // @@
        // @

        // Ejercicio 11
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@
        // @
        // @@@
        // @@@@@

    }
}
