import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        //Colores ANSI
        String black="\033[30m";            //1
        String red="\033[31m";              //2
        String green="\033[32m";            //3
        String yellow="\033[33m";           //4
        String blue="\033[34m";             //5
        String purple="\033[35m";           //6
        String cyan="\033[36m";             //7
        String white="\033[37m";            //8
        String reset="\u001B[0m";

        System.out.println("Ingrese un color: ");
        System.out.println("\t1 - negro");
        System.out.println("\t2 - rojo");
        System.out.println("\t3 - verde");
        System.out.println("\t4 - amarillo");
        System.out.println("\t5 - azul");
        System.out.println("\t6 - purpura");
        System.out.println("\t7 - cyan");
        System.out.println("\t8 - blanco");

        // int color=new java.util.Scanner(System.in).nextInt();    //nextInt() entero
        // if(color==1) System.out.println(black);
        // if(color==2) System.out.println(red);
        // if(color==3) System.out.println(green);
        // if(color==4) System.out.println(yellow);
        // if(color==5) System.out.println(blue);
        // if(color==6) System.out.println(purple);
        // if(color==7) System.out.println(cyan);
        // if(color==8) System.out.println(white);

        String color=new Scanner(System.in).nextLine();   //nextLine() String
        // el operador == solo compara números
        // para comparar String usar el método equals() o equalsIgnoreCase()

        //if(color.equals("negro")) System.out.println(black);
        //if(color.equals("rojo")) System.out.println(red);
        if(color.equalsIgnoreCase("negro"))     System.out.println(black);
        if(color.equalsIgnoreCase("rojo"))      System.out.println(red);
        if(color.equalsIgnoreCase("verde"))     System.out.println(green);
        if(color.equalsIgnoreCase("amarillo"))  System.out.println(yellow);
        if(color.equalsIgnoreCase("azul"))      System.out.println(blue);
        if(color.equalsIgnoreCase("purpura"))   System.out.println(purple);
        if(color.equalsIgnoreCase("cyan"))      System.out.println(cyan);
        if(color.equalsIgnoreCase("blanco"))    System.out.println(white);
        if(color.equalsIgnoreCase("1"))         System.out.println(black);
        if(color.equalsIgnoreCase("2"))         System.out.println(red);
        if(color.equalsIgnoreCase("3"))         System.out.println(green);
        if(color.equalsIgnoreCase("4"))         System.out.println(yellow);
        if(color.equalsIgnoreCase("5"))         System.out.println(blue);
        if(color.equalsIgnoreCase("6"))         System.out.println(purple);
        if(color.equalsIgnoreCase("7"))         System.out.println(cyan);
        if(color.equalsIgnoreCase("8"))         System.out.println(white);

        System.out.println("""
            ____________________¶¶¶
            _____________________¶
            _____________________¶¶¶¶¶¶¶¶¶¶¶¶¶
            _____________________¶¶¶___¶__¶_¶¶¶¶
            _____________________¶¶¶___¶¶¶¶___¶¶
            _____________________¶¶¶__¶¶¶¶¶___¶¶
            _____________________¶¶¶__¶¶¶¶¶___¶
            _____________________¶¶¶¶¶¶__¶¶___¶
            _____________________¶_________¶¶¶¶
            _____________¶¶¶¶¶¶¶¶¶¶¶¶¶
            _____________¶¶___________¶¶
            ______________¶____________¶
            ______________¶_____________¶
            _______________¶____________¶
            _______________¶____________¶_¶¶
            _______________¶__¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
            _____¶¶¶¶¶¶¶¶¶¶¶¶¶¶______________¶
            _____¶____________¶¶_____________¶¶____¶
            _____¶¶____________¶_____¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
            ______¶______¶¶¶¶¶¶¶¶¶¶¶¶¶¶______________¶
            ______¶¶_____¶¶___________¶______________¶¶
            _______¶______¶____________¶______________¶
            _______¶______¶¶___________¶_____________¶¶
            _______¶_______¶___________¶_____________¶¶
            ______¶¶_______¶___________¶¶____________¶
            ______¶¶¶¶¶¶¶¶¶¶¶__________¶¶___________¶¶
            ___________¶_¶_¶¶________¶¶¶_____¶¶¶¶¶¶¶¶_____¶¶¶
            ___________¶_¶_¶¶¶¶¶¶¶¶¶¶¶_¶¶¶¶¶¶¶_______¶¶¶¶¶__¶¶
            ¶¶¶¶¶¶_____¶_¶______¶¶_¶_______¶_¶¶¶¶¶¶¶¶¶___¶¶¶¶¶
            ¶¶___¶¶¶¶¶¶¶¶¶______¶¶_¶____¶¶¶¶¶¶¶________¶¶
            __¶¶________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶____¶¶______¶
            ____¶____________________________¶¶_¶____¶
            _____¶_____¶¶¶_____¶¶_____¶¶¶_____¶¶¶___¶¶
            ______¶___¶¶_¶¶___¶¶_¶____¶_¶¶__________¶
            ______¶¶____¶¶_____¶¶¶_____¶¶__________¶¶
            _______¶¶_____________________________¶¶
            ________¶¶___________________________¶¶
            _________¶¶________________________¶¶¶
            ___________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
              
        """);
        System.out.println(reset);
    }
}
