import java.text.DecimalFormat;
import java.time.LocalTime;
import java.util.Scanner;

public class Clase11 {
    public static void main(String[] args) {
        // Uso de Llaves

        // Modo de uso de llaves recomendado
        for (int a = 1; a < 10; a++) {
            System.out.println(a);
        }

        // Modo de uso de llaves Abreviado
        for (int a = 1; a < 10; a++)
            System.out.println(a);

        // Modo de uso de llaves expandido no recomendado
        for (int a = 1; a < 10; a++)
        {
            System.out.println(a);
        }

        // Variable de control externa
        System.out.println("********************************************");
        int x;
        for(x=1; x<=10; x++){
            System.out.println(x);
        }
        System.out.println("********************************************");
        System.out.println(x);
        System.out.println("********************************************");
        for(x++;x<=20;x++){
            System.out.println(x);
        }
        System.out.println("********************************************");
        for(;x<=30;x++){
            System.out.println(x);
        }

        // Recorrido con multiples variables de control
        for(int r=1, s=1; r<=5 && s<=10; r++,s++){
            System.out.println(r+" "+s);
        }

        // For anidado
        int cont=0;
        for(int r=1; r<=10; r++){
            for(int s=1; s<=10; s++){
                for(int t=1; t<=10; t++){
                    cont++;
                    System.out.println(r+", "+s+", "+t+", "+cont);    
                }
            }
        }

        // Horas de un reloj
        DecimalFormat df=new DecimalFormat("00");
        // for(int hora=0; hora<24; hora++){
        //     for(int minuto=0; minuto<60; minuto++){
        //         for(int segundo=0; segundo<60; segundo++){
        //             System.out.println(
        //                                 // df.format(hora)+":"+
        //                                 // df.format(minuto)+":"+
        //                                 // df.format(segundo)
        //                                 //hora+":"+minuto+":"+segundo
        //                             );
                    //try{ Thread.sleep(1000); } catch(Exception e){}
        //         }
        //     }
        // }

        //Ejemplo de reloj 
        // while(true){
        //     LocalTime lt=LocalTime.now();
        //     System.out.println(
        //                 df.format(lt.getHour())+":"+
        //                 df.format(lt.getMinute())+":"+
        //                 df.format(lt.getSecond())
        //     );
        //     try{ Thread.sleep(1000); } catch(Exception e){}
        // }

        // Loop Infinito
        //for(;;){}

        // Loop Infinito
        // for(int a=1;true; a++){
        //     System.out.println(a);
        // }

        // Loop Infinito
        // for(int a=1;a<=10 || true; a++){
        //     System.out.println(a);
        // }

        // Loop Infinito
        // for(int a=1;a<=10 || a>=0; a++){
        //     System.out.println(a);
        // }

        // Loop Infinito
        // for(int a=1;a<=10;){
        //     System.out.println(a);
        // }

        // Loop Infinito
        // for(int a=1;a<=10; a++){
        //     System.out.println(a--);
        // }

        // Ejemplo de uso de break
        // for(int a=1;true; a++){
        //     System.out.println(a);
        //     if(a>10) break;
        // }

        // ejemplo while y for con ingreso de datos externos

        //Ingrese 10 números por consola e informar la suma
        int suma=0;
        // for(int a=1; a<=10; a++){
        //     System.out.print("Ingrese un número: ");
        //     int numero=new Scanner(System.in).nextInt();
        //     suma+=numero;
        // }

        // int b=1;
        // while(b<=10){
        //     System.out.print("Ingrese un número: ");
        //     int numero=new Scanner(System.in).nextInt();
        //     suma+=numero;
        //     b++;
        // }

        // System.out.println("Total: "+suma);


        //Repetir fecha y hora hasta que el usuario ingrese por consola un NO
        String res="SI";
        // while(!res.equalsIgnoreCase("no")){
        //     Hoy.main(null);     //ejecuta el programa hoy
        //     System.out.println("Desea obtener de nuevo la fecha y hora?");
        //     res=new Scanner(System.in).nextLine();
        // }

        // for(;!res.equalsIgnoreCase("no");){
        //     Hoy.main(null);     //ejecuta el programa hoy
        //     System.out.println("Desea obtener de nuevo la fecha y hora?");
        //     res=new Scanner(System.in).nextLine();
        // }

        while(res.equalsIgnoreCase("si")){
            Hoy.main(null);     //ejecuta el programa hoy
            System.out.println("Desea obtener de nuevo la fecha y hora?");
            res=new Scanner(System.in).nextLine();
        }
        
        Hoy.main(null); 
        Programa.main(null);
        Hoy.main(null); 

    }
}