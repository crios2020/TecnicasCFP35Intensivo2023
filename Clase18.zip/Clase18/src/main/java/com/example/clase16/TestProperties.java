package com.example.clase16;

public class TestProperties {
    public static void main(String[] args) {
        System.out.println(System.getProperties());
    }
}
