package org.centro35.clase15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase15Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase15Application.class, args);
	}

}
