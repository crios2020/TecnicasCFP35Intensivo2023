public class Clase04 {
    public static void main(String[] args) {
        System.out.println("Clase 04");

        // Ejercicio 1 - Asignación básica
        // Analice el código a continuación y complete la tabla correspondiente.
        // Luego realice la codificación para confirmar que ha completado la tabla
        // correctamente.
        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x = x + 5;
        y = y + 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x = x - 5;
        y = y - 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x = x * 3;
        y = y * 5;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x = x / 2;
        y = y / 4;
        System.out.println(x);
        System.out.println(y);

        // Tabla para completar:
        //      x       y
        // A 
        // B 
        // C 
        // D 
        // E 

        // Ejercicio 2 - Asignación compacta
        // Analice el código a continuación y complete la tabla correspondiente. Luego
        // realice la codificación
        // para confirmar que ha completado la tabla correctamente.
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x += 5;
        y -= 15;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x++;
        y--;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x *= 4;
        y *= -3;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x /= 2;
        y /= 4;
        System.out.println(x);
        System.out.println(y);

        // Tabla para completar:
        // x y
        // A
        // B
        // C
        // D
        // E

        // Ejercicio 3 - Operadores aritméticos
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x = x + y;
        y = y + x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x = x - y;
        y = y - x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");

        x = x * y;
        y = x * x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x = y / x;
        y = x / y;
        System.out.println(x);
        System.out.println(y);

        // Tabla para completar:
        // x y
        // A
        // B
        // C
        // D
        // E

        // Ejercicio 4- Operadores aritméticos con asignación compacta
        System.out.println("A");
        x = 5;
        y = 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x += y;
        y += x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x -= y;
        y -= x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x *= y;
        y *= x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x /= y;
        y /= y;
        System.out.println(x);
        System.out.println(y);

        // Tabla para completar:
        // x y
        // A
        // B
        // C
        // D
        // E

        // Ejercicio 5- Operadores Aritméticos con asignación múltiple (suma y resta)
        System.out.println("A");
        x = 5;
        y = 10;
        int suma = 0;
        int resta = 0;
        System.out.println(x);
        System.out.println(y);
        System.out.println(suma);
        System.out.println(resta);
        System.out.println("B");
        suma = x + y;
        resta = x - y;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        suma = x + x;
        resta = y - y;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        suma = x + y + x;
        resta = x - x - 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        suma = y + x + x;
        resta = -x - y - y;
        System.out.println(x);
        System.out.println(y);

        // Tabla para completar:
        // x y suma resta
        // A
        // B
        // C
        // D
        // E

        // Ejercicio 6- Operadores Aritméticos con asignación múltiple (producto y
        // división)
        System.out.println("A");
        x = 5;
        y = 10;
        int multi = 1;
        int division = 1;
        System.out.println(x);
        System.out.println(y);
        System.out.println(multi);
        System.out.println(division);
        System.out.println("B");
        multi = x * y;
        division = x / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("C");
        multi = x * x;
        division = y / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("D");
        multi = x * y * x;
        division = y / x;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("E");
        multi = x * (-y);
        division = y / (-x);
        System.out.println(multi);
        System.out.println(division);

        // Tabla para completar:
        // x y multi division
        // A
        // B
        // C
        // D
        // E

        System.out.println("-- Operador Resto % --");
        System.out.println(33 % 5); // 3
        System.out.println(15 % 2); // 1
        System.out.println(14 % 2); // 0
        System.out.println(-14 % 2); // 0
        System.out.println(-15 % 2); // -1

        // Ejercicio 7- Operador Resto
        System.out.println("A");
        int n1 = 20;
        int n2 = 2;
        int n3 = n1 % n2;
        System.out.println(n3);
        System.out.println("B");
        n1 = 15;
        n2 = 2;
        n3 = n1 % n2;
        System.out.println(n3);
        System.out.println("C");
        n1 = 3;
        n2 = 20;
        n3 = n2 % n1;
        System.out.println(n3);
        System.out.println("D");
        n1 = 3;
        n2 = 15;
        n3 = n2 % n1;
        System.out.println(n3);

        // Tabla para completar:
        // n3
        // A 0
        // B 1
        // C 2
        // D 0
        /*
         * 
         * //Ejercicio 8 - Cadenas de Caracteres
         * 
         * System.out.println("A");
         * String palabra_1 = "Hola";
         * String palabra_2 = "Mundo";
         * String frase = "";
         * System.out.println(palabra_1);
         * System.out.println(palabra_2);
         * System.out.println(frase);
         * System.out.println("B");
         * frase = palabra_1 + palabra_2;
         * System.out.println(palabra_1);
         * System.out.println(palabra_2);
         * System.out.println(frase);
         * System.out.println("C");
         * frase = palabra_1 + " \t " + palabra_2;
         * System.out.println(palabra_1);
         * System.out.println(palabra_2);
         * System.out.println(frase);
         * System.out.println("D");
         * frase = palabra_1 + " \n " + palabra_2;
         * System.out.println(palabra_1);
         * System.out.println(palabra_2);
         * System.out.println(frase);
         * System.out.println("E");
         * frase = palabra_1 + " \n\t " + palabra_2;
         * System.out.println(palabra_1);
         * System.out.println(palabra_2);
         * System.out.println(frase);
         * 
         * // Tabla para completar:
         * // palabra_1 palabra_2 frase
         * // A
         * // B
         * // C
         * // D
         * // E
         * 
         * //Ejercicio 9 - Operadores Lógicos
         * System.out.println("A");
         * boolean b1 = true;
         * boolean b2 = false;
         * boolean b3 = !b1;
         * boolean b4 = !b2;
         * System.out.println(b3);
         * System.out.println(b4);
         * System.out.println("B");
         * b3 = b1 & b2;
         * 
         * b4 = b1 | b2;
         * System.out.println(b3);
         * System.out.println(b4);
         * System.out.println("C");
         * b3 = !(b1 & b2);
         * b4 = !(b1 | b2);
         * System.out.println(b3);
         * System.out.println(b4);
         * System.out.println("D");
         * b3 = !b1 & b2;
         * b4 = !b1 | b2;
         * System.out.println(b3);
         * System.out.println(b4);
         * System.out.println("E");
         * 
         * // Tabla para completar:
         * // b1 b2 b3 b4
         * // A
         * // B
         * // C
         * // D
         * // E
         */

        /*
         * Tabla de verdad
         * 
         * X Y OR AND XOR !=
         * F F F F F F
         * F V V F V V
         * V F V F V V
         * V V V V F F
         * 
         * 
         */

        // Estructura condicional IF
        if (true) {
            System.out.println("Estructura condicional IF");
            System.out.println("Verdad1");
            // código indentado
        }

        boolean log1=true;
        boolean log2=false;
        int nro1=5;
        if(log1){
            System.out.println("Verdad2");
        }

        if(log1==true){                 //No es necesario comparar
            System.out.println("Verdad3");
        }

        if(nro1==5){
            System.out.println("Verdad4");
        }

        if(nro1==5 && log1){
            System.out.println("Verdad5");
        }

        //Uso de llaves modo abreviado
        if(log1) System.out.println("Verdad6");

        //Uso de llaves expandido (Microsoft)
        if(log1)
        {
            System.out.println("Verdad7");
        }

        //Estructura if else
        if(!log1){
            System.out.println("Verdad8");
        }else{
            System.out.println("Falso8");
        }

        //Uso de llaves abreviados
        if(log1)    System.out.println("Verdad9");
        else        System.out.println("Falso9");

        //Uso de llaves expandido (Microsoft)
        if(log1)
        {
            System.out.println("Verdad10");
        }
        else
        {
            System.out.println("Falso10");
        }

        
        System.out.println("Fin del programa!");

        //TODO Modificar programa con método equals()
        //TODO Esctructura Switch
        //TODO Laboratorios de condicionales
    }
}