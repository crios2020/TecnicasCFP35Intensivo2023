public class Clase12 {
    public static void main(String[] args) {
        //Vectores o Arrays

        int[] numeros=new int[4];       //Declaración de vector
        String[] nombres=new String[4];  

        numeros[0]=1;
        nombres[0]="Juan";
        numeros[1]=2;
        nombres[1]="Jose";
        numeros[2]=3;
        nombres[2]="Lorena";
        numeros[3]=4;
        nombres[3]="Ana";
        //numeros[4]=5;
        //nombres[4]="Mirta";

        /*
         *  numeros     nombres         indice
         *      1       Juan            0
         *      2       Jose            1
         *      3       Lorena          2
         *      4       Ana             3
         * 
         */

        System.out.println(numeros[0]+" "+nombres[0]);
        System.out.println(numeros[1]+" "+nombres[1]);
        System.out.println(numeros[2]+" "+nombres[2]);
        System.out.println(numeros[3]+" "+nombres[3]);

        System.out.println("****************************");
        //Recorrido del vector
        for(int a=0; a<4; a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }

        //Método length
        System.out.println("Longitud numeros: "+numeros.length);

        //Recorrido usando el método length
        System.out.println("****************************");
        for(int a=0; a<numeros.length; a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }

        //Recorrido usando while
        System.out.println("****************************");
        int x=0;
        while(x<numeros.length){
            System.out.println(numeros[x]+" "+nombres[x]);
            x++;
        }


        //TODO Totalizar un vector

        //TODO Promediar un vector

        //TODO Máximos y Mínimos
        //TODO Contar Elementos

        //TODO Copiar Vectores
        //TODO Ordenar un vector

    }
}
