public class LaboratorioFor {
    public static void main(String[] args) {

        //Utilizar la estructura for

        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        System.out.println("-- Ejercicio 1 --");
        for(int a=1; a<=10; a++){
            System.out.println(a);
        }

        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
        System.out.println("-- Ejercicio 2 --");
        for(int a=1; a<=10; a+=2){
            System.out.println(a);
        }

        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        System.out.println("-- Ejercicio 3 --");
        for(int a=10; a>=1; a--){
            System.out.println(a);
        }

        // Ejercicio 4
        // Imprimir la suma de los números impares del 1 al 10.
        System.out.println("-- Ejercicio 4 --");
        int suma=0;
        // for(int a=1; a<=10; a+=2){
        //     suma+=a;
        // }
        for(int a=1; a<=10; a++){
            if(a%2!=0) suma+=a;
        }
        System.out.println("Total: "+suma);

        // Ejercicio 5
        // Mostrar la suma de 
        // la multiplicación de los números del 1 al 5      OK
        // con                                               +
        // la suma de los números del 1 al 5.               OK
        System.out.println("-- Ejercicio 5 --");
        suma=0;
        int multi=1;
        for(int a=1; a<=5; a++){
            suma+=a;
            multi*=a;
        }
        System.out.println("Total: "+(multi+suma));

        // Ejercicio 6
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @
        // @
        // @
        // @
        System.out.println("-- Ejercicio 6 --");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");
        // System.out.println("@");
        for(int a=1; a<=5; a++){
            System.out.println("@");
        }

        // Bonus Track
        // @@@@@
        System.out.println("-- Bonus Track --");
        //System.out.println("@@@@@");
        for(int a=1; a<=5; a++){
            System.out.print("@");
        }
        System.out.println();

        // Ejercicio 7
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @
        // @@
        // @
        System.out.println("-- Ejercicio 7 --");
        for(int a=1; a<=5; a++){
            if(a%2==0)  System.out.println("@@");
            else        System.out.println("@");
        }

        // Bonus Track
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        System.out.println("-- Bonus Track --");
        for(int b=1; b<=5; b++){
            for(int a=1; a<=5; a++){
                System.out.print("@");
            }
            System.out.println();
        }


        // Ejercicio 8
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        System.out.println("-- Ejercicio 8 --");
        for(int b=1; b<=5; b++){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }

        // Ejercicio 9
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 9 --");
        for(int b=5; b>=1; b--){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }
        // Ejercicio 10
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 10 --");
        for(int b=1; b<=5; b++){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }
        for(int b=4; b>=1; b--){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }

        // Ejercicio 11
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@
        // @
        // @@@
        // @@@@@

        System.out.println("-- Ejercicio 10 --");
        for(int b=5; b>=1; b-=2){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }
        for(int b=3; b<=5; b+=2){
            for(int a=1; a<=b; a++){
                System.out.print("@");
            }
            System.out.println();
        }

        
    }
}
